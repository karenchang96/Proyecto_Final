DROP TABLE IF EXISTS `airlines`;
CREATE TABLE `airlines` (
  `carrier` varchar(2) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`carrier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `airports`;
CREATE TABLE `airports` (
  `faa` varchar(3) NOT NULL,
  `name` varchar(45) NOT NULL,
  `lat` decimal(10,8) NOT NULL,
  `lon` decimal(11,8) NOT NULL,
  `alt` int NOT NULL,
  `tz` int NOT NULL,
  `dst` varchar(20) NOT NULL,
  `tzone` varchar(45) NOT NULL,
  PRIMARY KEY (`faa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `planes`;
CREATE TABLE `planes` (
  `tailnum` varchar(10) NOT NULL,
  `year` int NOT NULL,
  `type` varchar(45) NOT NULL,
  `manufacturer` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL,
  `engines` int NOT NULL,
  `seats` int NOT NULL,
  `speed` varchar(45) NOT NULL,
  `engine` varchar(45) NOT NULL,
  PRIMARY KEY (`tailnum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `weather`;
CREATE TABLE `weather` (
  `origin` varchar(3) NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `day` int NOT NULL,
  `hour` int NOT NULL,
  `temp` decimal(4,2) NOT NULL,
  `dewp` decimal(4,2) NOT NULL,
  `humid` decimal(4,2) NOT NULL,
  `wind_dir` int,
  `wind_speed` decimal(6,4) NOT NULL,   
  `wind_gust` decimal(7,5),
  `precip` int NOT NULL,
  `pressure` decimal(5,1),
  `visib` int NOT NULL,
  `time_hour` datetime(0) NOT NULL,
  PRIMARY KEY (`year`, `month`, `day`, `hour`, `origin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `flights`;
CREATE TABLE `flights` (
  `year` int NOT NULL,
  `month` int NOT NULL,
  `day` int NOT NULL,
  `dep_time` int NOT NULL,
  `sched_dep_time` int NOT NULL,
  `dep_delay` int NOT NULL,
  `arr_time` int NOT NULL,
  `sched_arr_time` int NOT NULL,
  `arr_delay` int NOT NULL,
  `carrier` varchar(2) NOT NULL,
  `flight` int NOT NULL,
  `tailnum` varchar(10) NOT NULL,
  `origin` varchar(3) NOT NULL,
  `dest` varchar(3) NOT NULL,
  `air_time` int NOT NULL,
  `distance` int NOT NULL,
  `hour` int NOT NULL,
  `minute` int NOT NULL,
  `time_hour` datetime(0) NOT NULL,
  CONSTRAINT `flights_fk1` FOREIGN KEY (`origin`) REFERENCES `airports` (`faa`), 
  CONSTRAINT `flights_fk2` FOREIGN KEY (`dest`) REFERENCES `airports` (`faa`), 
  CONSTRAINT `flights_fk3` FOREIGN KEY (`carrier`) REFERENCES `airlines` (`carrier`), 
  CONSTRAINT `flights_fk4` FOREIGN KEY (`tailnum`) REFERENCES `planes` (`tailnum`), 
  CONSTRAINT `flights_fk5` FOREIGN KEY (`year`, `month`, `day`, `hour`, `origin`) REFERENCES `weather` (`year`, `month`, `day`, `hour`, `origin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;